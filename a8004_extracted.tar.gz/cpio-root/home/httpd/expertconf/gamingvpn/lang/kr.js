// JavaScript Set Language (kr)
var D_lang = {
}
var S_lang = {
	"S_PAGE_TITLE"			: "게이밍 VPN",
	"S_MUDRUN_TITLE"		: "미꾸라지 VPN",

	"S_MUDFISH_NONE"		: "-",
	"S_MUDFISH_ON"			: "준비 중",
	"S_MUDFISH_INFO_DOWNLOADING"	: "최신 버전 확인 중",
	"S_MUDFISH_INFO_FAIL"		: "최신 버전 확인에 실패하였습니다. 인터넷 연결을 확인하여 주십시오.",
	"S_MUDFISH_CHECK_BINARY"	: "미꾸라지 파일 검사중",
	"S_MUDFISH_BINARY_DOWNLOADING"	: "미꾸라지 업데이트 중",
	"S_MUDFISH_BINARY_FAIL"		: "미꾸라지 다운로드에 실패하였습니다. 인터넷 연결을 확인하여 주십시오.",
	"S_MUDFISH_UNKNOWN_ERROR"	: "오류가 발생하였습니다.",
	"S_MUDFISH_OFF"			: "종료 중",
	"S_MUDFISH_READY"		: "실행 중",
	"S_MUDFISH_SETUPPAGE"		: "설정 페이지",
}
