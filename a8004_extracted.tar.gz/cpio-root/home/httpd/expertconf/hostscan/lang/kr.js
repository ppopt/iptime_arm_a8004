// JavaScript Set Language (kr)
var D_lang = {
}

var S_lang = {
	"S_PAGE_TITLE" : "호스트 검색",

	"S_PINGTEST" : "Ping Test",
	"S_TCPPORTSCAN" : "TCP 포트스캔",
	
	"S_PING_ICMP" : "ICMP",
	"S_PING_ARP" : "ARP",
	"S_PING_IPADDR" : "IP주소",
	"S_PING_COUNT" : "횟수",
	"S_PING_COUNTEND" : "번",
	"S_PING_TIMEOUT" : "시간제한",
	"S_PING_TIMEOUT_SEC" : "초",
	"S_PING_SIZE" : "크기",
	"S_PING_BYTES" : "bytes",
	
	"S_TCP_IPADDR" : "IP주소",
	"S_TCP_PORT" : "포트",

	"S_MAIN_STARTSTATUS" : "실행 상태",
	"S_MAIN_DEL" : "지우기",
	
	"S_EMPTY_C_HOSTSCAN_SPORT" : "시작포트를 입력하세요",
	"S_ERROR_C_HOSTSCAN_SPORT" : "시작포트가 잘못입력되었습니다.(1~65535)",
	"S_ERROR_C_HOSTSCAN_PORT_RANGE" : "포트범위가 잘못되었습니다.(1~65535)",
	
	"S_EMPTY_C_HOSTSCAN_COUNT" : "횟수를 입력하세요.",
	"S_ERROR_C_HOSTSCAN_COUNT" : "횟수가 잘못입력되었습니다.(1-999)",

	"S_EMPTY_C_HOSTSCAN_TIMEOUT" : "시간제한을 입력하세요.",
	"S_ERROR_C_HOSTSCAN_TIMEOUT" : "시간제한이 잘못입력되었습니다.(1-99)",

	"S_EMPTY_C_HOSTSCAN_SIZE" : "크기를 입력하세요",
	"S_ERROR_C_HOSTSCAN_SIZE" : "크기가 잘못입력되었습니다.(1-99999)",


	"S_EMPTY_HOSTSCAN_PINGADDR" : "IP주소를 입력하세요.",
	"S_ERROR_HOSTSCAN_PINGADDR" : "IP주소가 잘못입력되었습니다.",
	
	"":""
}
