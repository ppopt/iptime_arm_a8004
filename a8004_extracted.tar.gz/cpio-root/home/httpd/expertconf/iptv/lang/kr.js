// JavaScript Set Language (kr)
var D_lang = {
}
var S_lang = {
	"S_PAGE_TITLE"		: "IPTV 설정",

	"S_IGMP_MENU1"		: "IPTV 사용안함",
	"S_IGMP_MENU2"		: "공인IP방식(KT)",
	"S_IGMP_MENU2_SCS"	: "공인IP방식(서경, KT)",
	"S_IGMP_MENU3"		: "IGMP방식(SKT,LGU+)",
	"S_IGMP_MENU4"		: "IPTV 사용함",

	"S_IGMP_BUTTON1"	: "그룹 보기",

	"S_IGMP_TEXT1"		: " - 지정포트: ",
	"S_IGMP_TEXT2"		: "번",

	"S_GROUPLIST_TITLE"	: "그룹 리스트",

	"S_GROUPLIST_TITLE1"	: "그룹 주소",
	"S_GROUPLIST_TITLE2"	: "멤버 IP",
	"S_GROUPLIST_TITLE3"	: "포트",
	"S_GROUPLIST_TITLE4"	: "상태",

	"S_MEMBER_STATE1"	: "무선",
}
