// JavaScript Set Language (kr)
var D_lang = {
}
var S_lang = {
	"S_PAGE_TITLE"		: "커넥션 정보",

	"S_DELETEROUTE_TITLE"	: "커넥션 삭제", 

	"S_LIST_TITLE1"		: "현재/전체커넥션", 
	"S_LIST_TITLE2"		: "IP주소별 커넥션", 

	"S_LIST_SUB1"		: "수신패킷", 
	"S_LIST_SUB2"		: "송신패킷", 
	"S_LIST_SUB3"		: "수신바이트", 
	"S_LIST_SUB4"		: "송신바이트", 

	"S_CONNECTION_TYPE1"	: "TCP",
	"S_CONNECTION_TYPE2"	: "UDP",
	"S_CONNECTION_TYPE3"	: "ICMP",
	"S_CONNECTION_TYPE4"	: "Unknown",

	"S_GRAPH_INDEX1"	: "0",
	"S_GRAPH_INDEX2"	: "2",
	"S_GRAPH_INDEX3"	: "10",
	"S_GRAPH_INDEX4"	: "50",
	"S_GRAPH_INDEX5"	: "100%",

	"S_CONFIRM_TITLE"	: "커넥션 삭제",
	"S_CONFIRM_MSG"	: "선택하신 IP 주소의 커넥션을 삭제하시겠습니까?",
}
