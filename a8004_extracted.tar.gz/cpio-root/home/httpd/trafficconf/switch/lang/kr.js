// JavaScript Set Language (kr)
var D_lang = {
}
var S_lang = {
	"S_PAGE_TITLE"		: "스위치설정",

	"S_MIRRORING_TEXT1"	: "포트미러링",
	"S_MIRRORING_TEXT2"	: "인터넷으로 통신하는 모든 패킷을 ",
	"S_MIRRORING_TEXT3"	: "번 포트로 전송합니다.",

	"S_JUMBOFRAME_TEXT1"	: "점보 프레임 기능",
	"S_JUMBOFRAME_TEXT2"	: "모든 랜포트에 대하여 점보프레임을 허용합니다.",

	"S_TRUNK_TEXT1"		: "포트 트렁킹",
	"S_TRUNK_TEXT2"		: "포트 ",
	"S_TRUNK_TEXT3"		: "번을 Trunk 그룹으로 설정합니다.",
	"S_TRUNK_TEXT4"		: "Loop 방지를 위해 포트 트렁킹 활성화 후 랜선을 연결하세요.",

	"S_SWITCH_ALERT1"	: "포트 트렁킹에서 포트 ",
	"S_SWITCH_ALERT2"	: "번을 사용하고 있습니다.\n포트 트렁킹을 Off하고 사용하세요.",
	"S_SWITCH_ALERT3"	: "포트 미러링에서 포트 ",
	"S_SWITCH_ALERT4"	: "번을 사용하고 있습니다.\n포트 미러링을 Off하고 사용하세요.",

}
