// JavaScript Set Language (kr)
var D_lang = {
}
var S_lang = {
	"S_PAGE_TITLE"		: "USB 장치 관리",

	"S_USB_UNKNOWN"		: " 사용하지않음",
	"S_USB_REMOVED"		: " 제거됨",
	"S_USB_CONNECTED"	: " 사용중",
	"S_USB_TETHERING"	: " 사용중",
	"S_USB_WANLINK"		: " WAN 포트 제거 후 사용 가능",

	"S_SIZE_TEXT1"		: " 중 ",
	"S_SIZE_TEXT2"		: " 사용 가능",

	"S_DEVICE_TEXT0"	: "USB장치",
	"S_DEVICE_TEXT1"	: "저장장치 -",
	"S_DEVICE_TEXT2"	: "테더링장치 -",
	"S_DEVICE_TEXT3"	: "프린터 -",
	"S_DEVICE_TEXT4"	: "기타장치 -",
	"S_DEVICE_TEXT5"	: "장치 제거",
	"S_DEVICE_TEXT6"	: "저장위치 : ",
	"S_DEVICE_TEXT7"	: "연결되지 않음",
	"S_DEVICE_TEXT8"	: "장치 사용",

	"S_FILESYSTEM_STATE1"	: "마운팅 중...",

	"S_CUPS_SPOOLSIZE"	: "Spool 크기",
	"S_CUPS_SPOOLUSED"	: "사용 중",
	"S_CUPS_FAILED"		: "사용불가",
}
