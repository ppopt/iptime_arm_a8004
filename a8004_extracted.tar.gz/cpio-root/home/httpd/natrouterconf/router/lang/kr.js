// JavaScript Set Language (kr)
var D_lang = {
}
var S_lang = {
	"S_PAGE_TITLE"		: "라우팅 테이블 관리",

	"S_LIST_TITLE"		: "Type", 
	"S_ADDROUTE_TITLE"	: "라우팅 테이블 추가",
	"S_DELETEROUTE_TITLE"	: "라우팅 테이블 삭제", 
	"S_MODIFYROUTE_TITLE"	: "라우팅 테이블 수정", 

	"S_MAIN_SUB1"		: "Target/Mask", 
	"S_MAIN_SUB2"		: "Gateway", 

	"S_ROUTER_TYPE1"	: "NET", 
	"S_ROUTER_TYPE2"	: "HOST", 

	"S_ADD_INPUT1"		: "Type", 
	"S_ADD_INPUT2"		: "Target", 
	"S_ADD_INPUT3"		: "Mask", 
	"S_ADD_INPUT4"		: "Gateway",

	"S_INVALID_NUMBER" 	: "숫자만 입력하여 주십시오.",
	"S_INVALID_MASK"	: "Mask 범위는 1~32입니다.",
	"S_BLANKED_MASK"	: "Mask 값이 입력되지 않았습니다.",

	"S_IP_BLANKED" 		: "IP 주소가 입력되지 않았습니다.",
	"S_IP_NOTEXIST" 	: "사용할 수 없는 IP 주소입니다.(IP 주소 값의 범위는 0~255 입니다.)",

}
