<script>
//expertconf_hostscan
var ICMP_PING=0
var ARP_PING=1
var PING_SCAN=0
var TCP_PORT_SCAN=1
var SYSINFO_HOST_INVALID_TIMEOUT =   "시간제한을 입력하십시오"
var SYSINFO_HOST_TIMERANGE   =       "시간은 1초이상 입력해야 합니다."
var SYSINFO_HOST_INVALID_DATASIZE =  "크기를 입력하십시오"
var SYSINFO_HOST_DATARANGE    =      "0~65,500까지의 범위로 입력합니다."
var SYSINFO_HOST_INVALID_START  =    "시작 포트를 입력하십시오"
var SYSINFO_HOST_PORTRANGE      =    "0~65,535까지의 범위로 입력합니다."

var SYSINFO_HOST_DELETING      =    "지우는 중입니다."
var SYSINFO_HOST_STARTING      =    "시작 중입니다."
var SYSINFO_HOST_STOPPING      =    "중지 중입니다."
</script>
