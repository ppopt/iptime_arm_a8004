<script>
var SYSCONF_LOGIN_CANT_REMOVE_ID  = "세션방식에서는 계정 및 암호를 삭제할 수 없습니다."
var SYSCONF_LOGIN_CANT_REMOVE_WARNING="새로운 관리자 계정 및 암호를 입력하십시오."
var CANT_SET_DEFAULT_ID_PASS="초기화시 설정되는 계정 및 암호를 사용하였습니다.\n계정 및 암호를 변경하여 설정하십시오."
var SYSCONF_LOGIN_INVALID_NEW_PASS=     "새 암호가 일치하지 않습니다!"
var SYSCONF_LOGIN_RELOGIN         =     "암호를 변경하면, 새 암호로 다시 로그인하셔야 합니다!"
var SYSCONF_LOGIN_RELOGIN_SESSION  = "설정 후 로그인 페이지로 이동합니다. 계속하시겠습니까?"
var SYSCONF_LOGIN_SHOULD_HAVE_IDPASS  = "세션방식 사용 시 계정 및 암호를 먼저 설정해야 합니다."
var SYSCONF_LOGIN_INVALID_SESSION_TIMEOUT  = "자동 로그 아웃 시간은 1 ~ 60 분사이의 값을 입력하여야 합니다."
var SYSCONF_CAPTCHA_ATTEMPT_RANGE_WARNING = "실패 허용 횟수는 0~99까지 설정할 수 있습니다.";

var SYSCONF_LOGIN_APPLYSTR  = "적용 중 입니다.."
var SYSCONF_LOGIN_DELETESTR  = "삭제 중 입니다.."
var SYSCONF_EMAIL_INVALID  = "E-mail 형식이 올바르지 않습니다."
var SYSCONF_EMAIL_SMTP_INVALID  = "메일서버를 정확히 입력해 주십시오."
var SYSCONF_EMAIL_ACCOUNT_INVALID  = "메일서버 계정이 비어있거나 허용되지 않는 특수문자가 있습니다."
var SYSCONF_EMAIL_DEL_CONFIRM  = "관리자 E-mail 설정을 지웁니다.\n계속하시겠습니까?"
</script>
