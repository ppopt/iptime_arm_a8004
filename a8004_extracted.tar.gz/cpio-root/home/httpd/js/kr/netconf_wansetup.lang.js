<script>
var NETCONF_WANSETUP_APPLYSTR = '설정을 적용중입니다.';
var NETCONF_WANSETUP_CONNSTR = '연결중 입니다.';
var NETCONF_WANSETUP_DISCONNSTR = '연결을 해제중입니다.';

var NETCONF_INTERNET_KEEP_ALIVE_MSG="시간을 입력하십시오";
var NETCONF_INTERNET_DHCP_MTU_INVALID="MTU 값은 1500을 초과할수 없습니다.";
var NETCONF_INTERNET_PPP_MTU_INVALID="MTU 값은 1492을 초과할수 없습니다.";
var NETCONF_INTERNET_GW_INVALID_NETWORK="게이트웨이가 내부 네트워크와 같습니다!";
var NETCONF_WANSETUP_CONFIRM_WANINFO="인터넷 연결 정보를 확인 하시겠습니까?";
</script>
