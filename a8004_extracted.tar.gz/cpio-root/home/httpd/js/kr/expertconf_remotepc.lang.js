<script>
var EXPERTCONF_WOL_PC_NAME_IS_BLANK="PC 설명이 비어있습니다!"
var EXPERTCONF_WOL_DEL_PC="PC를 삭제 하시겠습니까 ?"
var EXPERTCONF_WOL_WANT_TO_WAKE_UP_PC ="PC 를 켜시겠습니까 ?"

var EXPERTCONF_WOL_ADDSTR = "PC를 추가 중 입니다.";
var EXPERTCONF_WOL_RUNSTR = "PC를 켜는 중 입니다.";
var EXPERTCONF_WOL_DELSTR = "PC를 삭제 중 입니다.";
</script>
