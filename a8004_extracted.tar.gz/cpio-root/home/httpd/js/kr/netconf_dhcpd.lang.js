<script>
var NETCONF_INTERNAL_INVALID_LEASETIME="IP 대여시간을 선택해 주세요."

var NETCONF_DHCP_APPLYSTR = '설정을 적용중입니다.';
var NETCONF_DHCP_REBOOTMSG1 = '<p>재시작 중입니다..</p><p>';
var NETCONF_DHCP_REBOOTMSG2 = ' 초 남음</p>';
var NETCONF_DHCP_INVALID_ADDR="IP 주소 대여 범위가 잘못되었습니다!"
var NETCONF_DHCP_SIP_CALC_FAIL = 'IP주소 대여 범위의 시작 IP 대역이 올바르지 않습니다.';
var NETCONF_DHCP_EIP_CALC_FAIL = 'IP주소 대여 범위의 끝 IP 대역이 올바르지 않습니다.';
var NETCONF_DHCP_CURPC_ALERT = '현재 설정페이지에 접속된 기기의 인터넷 연결이 끊어집니다.\n설정 하시겠습니까?';
var NETCONF_DHCP_UNPERMITTED_ALERT = '설명에 특수문자를 입력할 수 없습니다.';

var MSG_INVALID_DHCP_NETMASK="서브넷 마스크가 잘못되었습니다."
var MSG_INVALID_DHCP_GATEWAY="게이트웨이가 잘못되었습니다."

var MSG_ERROR_NETWORK_DHCP = 'IP주소 대여 범위에 네트워크 주소를 입력할 수 없습니다.';
var MSG_ERROR_BROAD_DHCP = 'IP주소 대여 범위에 브로드캐스트 주소를 입력할 수 없습니다.';
var MSG_DESC_TOO_LONG = '설명에는 최대 20 byte까지만 입력할 수 있습니다.\n한글의 경우 한 글자당 3byte로 계산됩니다.\n현재 계산된 byte : ';
</script>
