<script>

var MSG_NO_DEL_ROUTING_TABLE		= "삭제할 라우팅테이블을 선택해 주십시오";
var NETCONF_ROUTE_ENTRY_DELETE		= "선택된 라우팅 테이블을 삭제하시겠습니까?";
var NETCONF_ROUTE_ENTRY_SELECT		= "삭제할 라우팅테이블을 선택해 주십시오";
var MSG_MAX_IP_RULES			= "추가 가능한 최대 주소는 20개 입니다.";

</script>

