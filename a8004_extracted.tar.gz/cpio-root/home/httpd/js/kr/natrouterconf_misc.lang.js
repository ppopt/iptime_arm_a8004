<script>

var MSG_INPUT_TYPE_ERROR_LEASETIME_NUMBER	= 'IP 갱신 시간은 숫자만 입력 가능합니다';
var MSG_INPUT_TYPE_ERROR_FTPPORT_NUMBER		= '포트 번호는 숫자만 입력 가능합니다';

var MSG_RESTART_CONFIRM_NAT			= '인터넷 공유기능 설정을 변경하면, 공유기를 재시작 하여야합니다.\n계속하시겠습니까?';
var NATCONF_INTAPPS_NO_MORE_ADD_FTP_PORT	= "설정할 수 있는 포트의 갯수를 초과했습니다"
var NATCONF_TWINIPDMZ_UPDATE_TIME="IP 갱신 시간은 60초 이상이어야 합니다."
var NATCONF_TWINIPDMZ_WARNING="현재 접속한 PC는 Twin IP를 사용하고 있습니다. Twin IP를 해제 하시면 해당 PC는 IP 주소를 재설정 해야 정상적으로 사용할 수 있습니다.  (설정 해제 직 후 부터는 ipTIME 웹 설정 페이지 접속을 포함한 모든 통신이 이루어 지지 않습니다.)  계속 진행 하시겠습니까 ?"


</script>
