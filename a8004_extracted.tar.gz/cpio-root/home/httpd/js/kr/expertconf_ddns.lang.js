<script>
var EXPERTCONF_DDNS_DELCONFIRM = "DDNS를 삭제할 경우, DDNS 주소 등록이 취소됩니다.\n또한, 설정되어 있던 DDNS주소를 다른 사용자가\n사용할 수도 있습니다.\n계속하시겠습니까?";
var EXPERTCONF_DDNS_ADDSTR = "DDNS를 등록중 입니다.";
var EXPERTCONF_DDNS_DELSTR = "DDNS를 삭제중 입니다.";
var EXPERTCONF_DDNS_REFRESHSTR = "DDNS를 갱신중 입니다.";
var EXPERTCONF_DDNS_HOSTNAMECHECK = "호스트 이름을 정확히 입력해 주십시오.\n영문, 숫자, 하이픈(-) 만 허용됩니다.";
var EXPERTCONF_DDNS_USERIDCHECK = "사용자 ID를 정확히 입력해 주십시오.\nE-mail 형식으로 입력해야 합니다.";
var EXPERTCONF_DDNS_CAPTCHACHECK = "보안 문자를 입력해 주십시오.";
var DDNS_HOSTNAME_RULE_TXT="호스트 이름은 영문 및 숫자, 하이픈(-) 만 가능합니다."
</script>
