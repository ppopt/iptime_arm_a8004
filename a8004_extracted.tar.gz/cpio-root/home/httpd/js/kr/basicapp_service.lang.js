<script>
var MSG_INVALID_FOLDER_STR="잘못된 폴더 이름을 입력하였습니다.";
var MSG_INVALID_FOLDER_NON_ASCII_STR="한글 폴더명을 입력할 수 없습니다.";
var MSG_INVALID_FOLDER_2DOTS_STR=".. 은 폴더명으로 사용할 수 없습니다.";
var MSG_INVALID_FOLDER_DOT_STR=". 으로 시작된 폴더명을 사용할 수 없습니다.";
var MSG_CANT_BE_USED="는 사용할 수 없습니다.";
var MSG_INVALID_PASSWORD_STR="잘못된 암호를 입력하였습니다.";
var NASCONF_SAMBANAME_BLANK= "서버이름을 입력해야 합니다.";
var NASCONF_SAMBAGROUP_BLANK= "작업그룹을 입력해야 합니다.";

var EXPERTCONF_IPTIMEDDNS_INVALID_USERID= "정확한 E-mail 주소를 입력하십시오.";
var EXPERTCONF_IPTIMEDDNS_INVALID_HOSTNAME = "호스트 이름에 '_' 또는 '.'은 사용할 수 없습니다.";

var MSG_REMOVE_IPDISK_DDNS="ipDISK서비스를 중단할 경우,설정된 ipDISK주소 등록이 취소됩니다..\n또한, 설정되었던 ipDISK 주소를 다른 사용자가 사용할 수도 있습니다.\n계속하시겠습니까?";
var MSG_APACHE_INVALID_FS="설정할 DocumentRoot의 파일시스템이 FAT32또는 ExFAT입니다.\n이 경우 [Plug-in App기능]을 사용할 수 없습니다.\nNTFS또는 Ext2/3/4(리눅스)파일 시스템을 사용할 것을 권장합니다.\n그래도 계속하시겠습니까?";

var MSG_SELECT_MYSQL_FOLDER_ERR="DB폴더를 선택하여 주십시오.";
var MSG_SELECT_APACHE_DOC_FOLDER_ERR="DocumentRoot를 선택하여 주십시오.";
var MSG_SELECT_APACHE_SERVER_FOLDER_ERR="ServerRoot를 선택하여 주십시오.";
var MSG_NEW_FOLDER_ERR="생성할 폴더명을 입력하여 주십시오.";
var MSG_MEDIA_NAME_ERR="서버이름을 입력하여 주십시오.";
var MSG_SELECT_MEDIA_FOLDER_ERR="미디어 폴더를 선택하여 주십시오.";
var MSG_SELECT_TORRENT_FOLDER_ERR="다운로드 폴더를 선택하여 주십시오.";
var MSG_SELECT_FOLDER_ERR="백업폴더를 선택하여 주십시오.";
var MSG_DUPLICATE_SERVICE_ID="동일한 사용자ID를 설정할 수 없습니다.";
var MSG_ENABLE_ONE_SERVICE_ID="최소 한명이상의 사용자를 설정해야 합니다.";
var UNALLOWED_ID_MSG  = "허용되지 않은 사용자 ID입니다.";

var MSG_APACHE_DOCROOT_SERVERROOT_WARNING = "DocumentRoot와 ServerRoot를 같은 폴더로 지정할 수 없습니다.";

var NASCONF_ENTWARE_ACCESS_DENY = "관리자 계정 설정 후 다시 실행해 주시기 바랍니다.";
var MSG_SELECT_ENTWARE_FOLDER_ERR="설치 폴더를 선택하여 주십시오.";
var NASCONF_ENTWARE_INSTALL_CONDITION_CHECK = "TELNET 실행 또는 Entware 설치를 위한 폴더가 준비되지 않았습니다.\n폴더 확인 후 다시 실행해 주십시오.";
var NASCONF_ENTWARE_STATUS_INSTALLING = '설치중';
var NASCONF_ENTWARE_STATUS_READY = '설치 완료';
var NASCONF_ENTWARE_STATUS_ERROR = '설치 실패';
</script>
