<script>

var PORTFORWARD_APPLY_STRING = "적용";
var PORTFORWARD_MODIFY_STRING = "수정";

var PORTFORWARD_IPADDR_INVALID = "IP 주소를 정확히 입력하여 주십시오.";
var PORTFORWARD_RULE_NAME_BLANKED = "규칙 이름을 입력하여 주십시오.";
var PORTFORWARD_PORT_INVALID = "포트 번호를 정확히 입력하여 주십시오.";

var PORTFORWARD_RULE_DELETE = "규칙을 삭제하시겠습니까?";
var PORTFORWARD_NOT_SELECTED_STRING = "선택된 규칙이 없습니다.";
var PORTFORWARD_RULE_NAME_INVALID = "규칙 이름에 허용되지 않는 특수 문자가 있습니다."
var PORTFORWARD_INT_IP_ALERT = "공유기 내부 주소는 포트포워드 할 수 없습니다.";
var PORTFORWARD_BROD_IP_ALERT = "브로드캐스트 주소는 포트포워드 할 수 없습니다.";
var PORTFORWARD_MAX_RULE_ALERT = "규칙을 더 추가할 수 없습니다.";
var PORTFORWARD_FILE_NOT_EXIST = "파일이 선택되지 않았습니다.";
var PORTFORWARD_RULE_NAME_EXIST = "중복된 규칙 이름이 있습니다.\n다른 규칙 이름으로 입력해 주세요.";

</script>
