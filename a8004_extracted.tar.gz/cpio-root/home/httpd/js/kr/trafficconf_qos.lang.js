<script>

var QOS_SMARTQOS_WARNING_USERRULE_DELETE	= "설정되어 있는 사용자 규칙이 모두 삭제됩니다. 계속 진행하시겠습니까?";
var QOS_USERRULE_WARNING_NEED_BANDWIDTH		= "전체 인터넷 속도를 설정하여 주십시오.";
var QOS_USERRULE_WARNING_PRIORITY_ORDER		= "'최소속도보장'이 '최대속도제한'보다 우선순위가 높아야 합니다.\n우선순위를 자동으로 재조정 하시겠습니까?";
var QOS_USERRULE_WARNING_BANDWIDTH_SPEED	= "인터넷 속도가 잘못되었습니다.";

var QOS_COMMON_EXCCED_MAX_SPEED			= "최대 인터넷 속도범위를 초과했습니다."
var QOS_COMMON_ISOLATED_EXCEED			= "최소 보장 속도의 합은 최대 인터넷 속도를 초과할 수 없습니다."
var QOS_PROTOCOL_SELECT				= "프로토콜을 선택해야 합니다."
var QOS_PORT_PORTRANGE				= "1~65,535까지의 범위로 입력해야 합니다."
var QOS_PORT_INVALID_EXT_PORT_RANGE		= "포트 범위가 잘못되었습니다!"
var QOS_BADNWIDTH_EMPTY				= "속도설정을 입력해야 합니다."
var QOS_BPI_RANGE				= "IP 주소별 대역폭 개별할당 범위가 잘못되었습니다. (허용갯수 : 2 ~ 31)"

//var QOS_BASIC_WARNING				= "사용자 규칙이  설정되어 있다면 모두 삭제 됩니다. 계속 진행 하시겠습니까 ?"
//var QOS_COMMON_EXCCED_MAX_CLASS			= "클래스 최대 갯수를 초과했습니다."
//var QOS_COMMON_NO_CHANGE_DIRECTION		= "클래스의 방향은 변경할 수 없습니다."
//var QOS_COMMON_ONLY_DIGIT			= "정수만 입력할 수 있습니다 !"
//var QOS_COMMON_BASIC_SETUP_FIRST		= "Qos 기본 설정 되어 있지 않습니다 !"
//var QOS_RATE_RANGE				= "32 Kbps ~ 50 Mbps 범위를 준수해야 합니다."

var MSG_QOS_REBOOT				= "QOS 설정을 변경하기위해서는 시스템을 재시작해야합니다. 계속하시겠습니까?"


</script>
