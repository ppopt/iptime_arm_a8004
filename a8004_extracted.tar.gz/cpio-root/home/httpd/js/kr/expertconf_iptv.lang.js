<script>

var MSG_IGMP_REBOOT = "IPTV 설정을 변경하기위해 시스템을 재시작합니다. 계속하시겠습니까?"

</script>
