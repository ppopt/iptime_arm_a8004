<script>
var NETCONF_INTERNAL_INVALID_LEASETIME="IP 대여시간을 선택해 주세요."

var NETCONF_LANSETUP_APPLYSTR = '설정을 적용중입니다.';
var NETCONF_LANSETUP_PARTAPPLY = '내부 네트워크 자동 검색중..';
var NETCONF_LANSETUP_REBOOTMSG1 = '<p>재시작 중입니다..</p><p>';
var NETCONF_LANSETUP_REBOOTMSG2 = ' 초 남음</p>';
var NETCONF_LANSETUP_CURPC_ALERT = '현재 설정페이지에 접속된 기기의 인터넷 연결이 끊어집니다.\n설정 하시겠습니까?';

var NETCONF_LANSETUP_HUBAP_ALERT = '내부 게이트웨이 설정 시, DHCP 서버를 중단 합니다.\n계속하시겠습니까?';
var NETCONF_LANSETUP_INVALID_GATEWAY="게이트웨이가 잘못되었습니다."
var NETCONF_LANSETUP_PLZ_CHANGE="내부 IP 주소와 내부 게이트웨이를\n동일한 서브네트워크로 변경하십시오."

var LANSETUP_SEARCH_SUCCESS="내부 네트워크 검색 성공"
var LANSETUP_SEARCH_FAILED="내부 네트워크 검색 실패"
var LANSETUP_SEARCH_FAILED2="수동으로 설정하십시오."

var MSG_ERROR_NETWORK_LANIP = '내부 IP주소는 네트워크 주소와 같을 수 없습니다.';
var MSG_ERROR_BROAD_LANIP = '내부 IP주소는 로컬 브로드캐스트 주소와 같을 수 없습니다.';
var MSG_DESC_TOO_LONG = '설명에는 최대 20 byte까지만 입력할 수 있습니다.\n한글의 경우 한 글자당 3byte로 계산됩니다.\n현재 계산된 byte : ';
var LANSETUP_RESTART_CONFIRM_CHANGE_LANIP='공유기가 재시작 됩니다.\n계속하시겠습니까?';
var LANSETUP_RESTART_CONFIRM_CHANGE_LANIP_FAKE_TWINIP='TwinIP가 설정된 경우에는 TwinIP 설정이 해지되고,\n공유기가 재시작 됩니다. 계속하시겠습니까?';
var LANSETUP_REBOOT_CHANGEIP_RETRY_LOGIN="내부 네트워크 설정이 변경되어 다시 로그인하셔야 합니다."
</script>
