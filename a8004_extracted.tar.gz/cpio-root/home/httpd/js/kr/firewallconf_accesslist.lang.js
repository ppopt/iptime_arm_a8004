<script>
var ACCESSLIST_NOIPLISTMSG_1="설정된 IP가 없습니다. 현재 접속하신 PC("
var ACCESSLIST_NOIPLISTMSG_2=")를 접속 보안에 추가하시겠습니까?"
var ACCESSLIST_WRONG_INPUT_IP="IP 주소가 잘못 입력 되었습니다."
var ACCESSLIST_WRITE_EXPLAIN="설명을 입력하셔야 합니다."
var ACCESSLIST_DEL_WANT="삭제하시겠습니까?"

var DESC_INVALID_ARP_PERIOD="초당 ARP개수를 1 ~ 100 사이의 수로 설정합니다."
var ACCESSLIST_APPLYSTR = "적용 중 입니다.";
var ACCESSLIST_ADDSTR = "추가 중 입니다.";
var ACCESSLIST_DELSTR = "삭제 중 입니다.";
var ACCESSLIST_PLEASE_CHECK = "삭제할 항목을 체크하여 주십시오.";
var ACCESSLIST_NO_MORE = "더 이상 추가할 수 없습니다.";
var ACCESSLIST_INVALID_WHITES = "접근 허용 도메인이 잘못 입력되었습니다.\n콤마(,)로 구분하여 최대 3개까지 URL을 입력하십시오.";
var MSG_DESC_TOO_LONG = '최대 32 byte까지만 입력할 수 있습니다.\n한글의 경우 한 글자당 3byte로 계산됩니다.\n현재 계산된 byte : ';
var ACCESSLIST_AUTO_NOADD = '접속 보안 설정 시,\n현재 접속된 IP의 설정 페이지 접속이 끊어집니다.\n계속 진행하시겠습니까?';
var ACCESSLIST_EXTOFF_CONFIRM = '원격 관리 포트 해제 시,\n현재 접속된 IP의 설정 페이지 접속이 끊어집니다.\n계속 진행하시겠습니까?';
</script>
