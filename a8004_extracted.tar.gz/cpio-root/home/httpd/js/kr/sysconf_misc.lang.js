<script>
var MSG_RESTART_CONFIRM_DEFAULT		= '공유기 설정을 초기화하면, 공유기를 재시작 하여야합니다.\n계속하시겠습니까?';
var MSG_RESTOREFILE_BLANK		= "복구할 설정파일을 선택하십시오."
var MSG_RESTART_CONFIRM_RESTORE		= '설정을 복구하면 공유기가 재시작됩니다.\n 계속하시겠습니까?';
var SYSCONF_RESTORE_RETRY_CONNET	= "설정 복구된 내부 IP 주소로 다시 접속하셔야 합니다."

var SYSCONF_HOSTNAME_WARNING		= "공유기 이름은 1글자 이상이어야 합니다.";
var SYSCONF_HOSTNAME_SPECIAL_WARNING	= "공유기 이름에 특수문자 및 공백은 들어갈 수 없습니다.";
var SYSCONF_LED_START_TIME_ALERT	= "시작시간이 끝나는 시간보다 클 수 없습니다.";
var SYSCONF_APPLY_BUTTON_NAME		= "다시 시작";
var SYSCONF_APPLY_ORIGINAL_VALUE	= "적용";
var SYSCONF_FAN_ALERT			= "온도범위 설정이 잘못되었습니다.";

var SYSCONF_INVALID_HOSTNAME		= "잘못된 호스트이름입니다.";
var UNPERMITTED_STR_PREFIX		= "사용할수 없는 문자 :";
var SYSCONF_INVALID_TEMPERATURE		= "잘못된 온도를 입력하였습니다.(온도 <= 100)";

var SYSCONF_SET_URL_TAG			= "URL TAG값을 입력하십시오.";
var SYSCONF_MISC_MULTILANG_WARNING	= "설정 후 시스템 요약 정보 페이지로 이동합니다. 계속하시겠습니까?"

var MSG_RESTART_PORT_ROLE		= "유선 포트 기능 변경 시 시스템이 재시작됩니다.\n시스템이 재시작 된 이후, 망 구성에 따라서 관리도구로의 자동 재접속이 실패할 수 있습니다.\n계속하시겠습니까?"

</script>

