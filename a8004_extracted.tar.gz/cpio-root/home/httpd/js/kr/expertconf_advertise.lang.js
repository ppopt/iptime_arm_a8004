<script>
var EXPERTCONF_ADVERTISE_ADDSTR = "추가 중 입니다.";
var EXPERTCONF_ADVERTISE_DELSTR = "삭제 중 입니다.";
var EXPERTCONF_ADVERTISE_APPLYSTR = "적용 중 입니다.";

var EXPERTCONF_ADVERTISE_URLREDIR_INVALID = "공지/광고 URL을 정확히 입력해 주십시오.";
var EXPERTCONF_ADVERTISE_CYCLE_INVALID = "재접속 주기를 5분 단위로 입력해 주십시오.";
var EXPERTCONF_ADVERTISE_BTNMSG_INVALID = "확인버튼 문구에 허용되지 않는 특수문자가 입력되어 있습니다.";
var EXPERTCONF_ADVERTISE_USERMSG_INVALID = "확인시 문구에 허용되지 않는 특수문자가 입력되어 있습니다.";
var EXPERTCONF_ADVERTISE_USERMSG2_INVALID = "확인후 문구에 허용되지 않는 특수문자가 입력되어 있습니다.";
var EXPERTCONF_ADVERTISE_WHITELIST_INVALID = "White List에 정확한 URL을 입력하여 주십시오.";

var EXPERTCONF_ADVERTISE_NOCHECK_DEL = "삭제할 예외 기기를 체크해 주십시오.";
var EXPERTCONF_ADVERTISE_IPRANGE_INVALID = "IP 주소 범위가 잘못 입력되었습니다.";
var MSG_DESC_TOO_LONG = '최대 255 byte까지만 입력할 수 있습니다.\n한글의 경우 한 글자당 3byte로 계산됩니다.\n현재 계산된 byte : ';
var MSG_DESC_TOO_LONG2 = '최대 128 byte까지만 입력할 수 있습니다.\n한글의 경우 한 글자당 3byte로 계산됩니다.\n현재 계산된 byte : ';
var ACCESSLIST_WRITE_EXPLAIN="설명을 입력하셔야 합니다."
</script>
