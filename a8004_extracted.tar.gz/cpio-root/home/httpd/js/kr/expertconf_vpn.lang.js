<script>
var EXPERTCONF_VPN_VPN_ACCOUNT_IS_BLANK="VPN접속 계정이 올바르지 않습니다."
var EXPERTCONF_VPN_VPN_PASSWORD_IS_BLANK="VPN접속 암호를 입력해야 합니다"
var EXPERTCONF_VPN_IP_ADDRESS_IS_INVALID="IP 주소를 입력해야 합니다"
var EXPERTCONF_VPN_DO_YOU_WANT_DELETE="계정을 삭제하겠습니까?"
var EXPERTCONF_VPN_IPADDR_OVERLAP="할당 될 IP 주소가 중복됩니다."
var EXPERTCONF_VPN_ACCOUNT_OVERLAP="VPN 접속 계정이 존재합니다."

var EXPERTCONF_VPN_APPLYSTR = '설정을 적용중입니다.';
var EXPERTCONF_VPN_DISCONNSTR = '연결을 해제중입니다.';
var EXPERTCONF_VPN_DELETESTR = '계정을 삭제중입니다.';
var EXPERTCONF_VPN_ADDSTR = '계정을 추가중입니다.';
var EXPERTCONF_VPN_NOSELECT = '선택된 항목이 없습니다.';

var EXPERTCONF_VPN_NO_PSK = '비밀키를 입력하지 않았습니다.';
</script>
