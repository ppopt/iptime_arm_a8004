<script language="javascript" type="text/javascript">

var MBRIDGE_WEP_ALERT 			= "WEP 암호화 방식은 보안이 취약하여 지원하지 않습니다.\n다른 암호화 방식을 사용하여 주십시오.";
var MBRIDGE_DISCONNECT_CONFIRM_TXT	= "현재 무선으로 설정 페이지에 접속되어 있습니다.\n설정 변경 시, 무선 연결이 끊어질 수 있습니다.\n계속 진행하시겠습니까?";
var MBRIDGE_STOPPED			= "연결이 중단됨";
var MBRIDGE_INVALID_PW			= "비밀번호가 잘못됨";
var MBRIDGE_WWAN_CONNECTED		= "에 무선WAN으로 연결됨";
var MBRIDGE_BRIDGE_CONNECTED		= "에 무선 브리지로 연결됨";
var MBRIDGE_WDS_CONNECTED		= "에 WDS로 설정됨";
var MBRIDGE_TRY_CONNECT			= "에 연결 시도 중...";
var MBRIDGE_NORM_POWER			= "수신감도";
var MBRIDGE_CONNECTION_FAILED		= "연결 실패";

var MSG_INVALID_AUTH_FOR_BRIDGE		= "무선 멀티브리지를 통해 연결할 수 없는 AP입니다."

var MSG_APMODE_TURNON_WANRING 		= "기본 무선 네트워크를 ON으로 설정 후 사용 가능합니다.";
</script>
