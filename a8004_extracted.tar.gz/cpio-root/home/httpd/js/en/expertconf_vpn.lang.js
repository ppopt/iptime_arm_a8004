<script>
var EXPERTCONF_VPN_VPN_ACCOUNT_IS_BLANK="VPN account is invalid"
var EXPERTCONF_VPN_VPN_PASSWORD_IS_BLANK="VPN password is blank"
var EXPERTCONF_VPN_IP_ADDRESS_IS_INVALID="IP Address is blank"
var EXPERTCONF_VPN_DO_YOU_WANT_DELETE="Do you want to delete a Account?"
var EXPERTCONF_VPN_IPADDR_OVERLAP="IP Address is overlapped"
var EXPERTCONF_VPN_ACCOUNT_OVERLAP="VPN Account is overlapped."

var EXPERTCONF_VPN_APPLYSTR = 'Applying...';
var EXPERTCONF_VPN_DISCONNSTR = 'Disconnecting selected users..';
var EXPERTCONF_VPN_DELETESTR = 'Deleting selected users..';
var EXPERTCONF_VPN_ADDSTR = 'Adding new user..';
var EXPERTCONF_VPN_NOSELECT = 'No select items.';

var EXPERTCONF_VPN_NO_PSK = 'PSK is blank.';
</script>
