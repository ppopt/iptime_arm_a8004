<script language="javascript" type="text/javascript">

var MACAUTH_DISCONNECT_CONFIRM_TXT	= "Connection will be disconnected";
var MACAUTH_AUTH_TXT	= "Authentication";

</script>
