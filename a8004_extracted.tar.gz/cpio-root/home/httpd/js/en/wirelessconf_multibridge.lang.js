<script language="javascript" type="text/javascript">

var MBRIDGE_WEP_ALERT 			= "WEP encryption is not supported";
var MBRIDGE_DISCONNECT_CONFIRM_TXT	= "Connection will be disconnected";
var MBRIDGE_STOPPED			= "Stopped";
var MBRIDGE_INVALID_PW			= "Invalid password";
var MBRIDGE_WWAN_CONNECTED		= "Connected(Wireless WAN)";
var MBRIDGE_BRIDGE_CONNECTED		= "Connected(Bridge)";
var MBRIDGE_WDS_CONNECTED		= "configured WDS";
var MBRIDGE_TRY_CONNECT			= "Trying to connect";
var MBRIDGE_NORM_POWER			= "Signal";
var MBRIDGE_CONNECTION_FAILED		= "Connection Failed";

var MSG_INVALID_AUTH_FOR_BRIDGE		= "This AP can't be connected by Bridge.";

var MSG_APMODE_TURNON_WANRING 		= "This function can be used only if wireless function is on.";

</script>
