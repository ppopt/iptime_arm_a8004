<script>
var MSG_CONNECTION_MAX_WARNING="Continue?";
var MSG_CONNECTION_MAX_TOO_SMALL="Too small max connection. Set over 512.";
var MSG_UDP_CONNECTION_MAX_TOO_BIG="Max UDP connection should be set between 10 and max connection.";
var MSG_ICMP_CONNECTION_MAX_TOO_BIG="Max ICMP connection should be less than max connection.";
var MSG_INVALID_RATE_PER_MAX="Invalid connection rate per 1 PC.";
var TRAFFICCONF_CONNCTRL_INVALID_TIME = "Invalid Time Value";


</script>
