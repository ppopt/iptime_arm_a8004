<script>
var EXPERTCONF_WOL_PC_NAME_IS_BLANK="PC name is blank."
var EXPERTCONF_WOL_DEL_PC="Do you want to delete PC?"
var EXPERTCONF_WOL_WANT_TO_WAKE_UP_PC ="Do you want to wake up this PC?"

var EXPERTCONF_WOL_ADDSTR = "Adding PC..";
var EXPERTCONF_WOL_RUNSTR = "Wake up PC..";
var EXPERTCONF_WOL_DELSTR = "Deleting..";
</script>
