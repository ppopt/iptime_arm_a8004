<script>
var ACCESSLIST_NOIPLISTMSG_1="No configured IP Address. Would you add your computer's IP Address("
var ACCESSLIST_NOIPLISTMSG_2=") connected?"
var ACCESSLIST_WRONG_INPUT_IP="Invalid IP Address."
var ACCESSLIST_WRITE_EXPLAIN="Description is blank."
var ACCESSLIST_DEL_WANT="Do you want to delete item?"

var DESC_INVALID_ARP_PERIOD="ARP packet/sec should be 1 ~ 100."
var ACCESSLIST_APPLYSTR = "Applying..";
var ACCESSLIST_ADDSTR = "Adding..";
var ACCESSLIST_DELSTR = "Deleting..";
var ACCESSLIST_PLEASE_CHECK = "Please check a delete item";
var ACCESSLIST_NO_MORE = "No more add rule.";
var ACCESSLIST_INVALID_WHITES = "Whitelist is invalid.";
var MSG_DESC_TOO_LONG = 'You can enter 32 bytes\nif non-ascii character is 3 bytes each\ncurrent byte : ';
var ACCESSLIST_AUTO_NOADD = 'If you set up a access,\nwill be disconnected setup page.\ndo you want continue?';
var ACCESSLIST_EXTOFF_CONFIRM = 'If you turn off use port,\nwill be disconnected setup page.\ndo you want continue?';
</script>
