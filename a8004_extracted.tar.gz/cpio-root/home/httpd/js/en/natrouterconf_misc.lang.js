<script>

var MSG_INPUT_TYPE_ERROR_LEASETIME_NUMBER	= 'Invalid number';
var MSG_INPUT_TYPE_ERROR_FTPPORT_NUMBER		= 'Invalid port number';

var MSG_RESTART_CONFIRM_NAT='System will restart to change NAT configuration.\nAre you sure to continue ?';
var NATCONF_INTAPPS_NO_MORE_ADD_FTP_PORT="No more add FTP port."
var NATCONF_INTAPPS_FTP_PORT_EMPTY="Port Number is blank."
var NATCONF_INTAPPS_FTP_PORT_INVALID= "Invalid Port Number."


var NATCONF_TWINIPDMZ_UPDATE_TIME="IP Update Duration time should be more than 60 second."
var NATCONF_TWINIPDMZ_WARNING="This PC use Twin IP. If Twin IP is not used, The IP configuration of this PC should be reconfigured.\nAre you sure to continue ?"


</script>
