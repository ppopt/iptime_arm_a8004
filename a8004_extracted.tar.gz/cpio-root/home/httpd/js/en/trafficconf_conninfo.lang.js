<script>
var TRAFFICCONF_CONNINFO_DELETE_CONN="Do you want to delete a connection of designated IP address?"

</script>
