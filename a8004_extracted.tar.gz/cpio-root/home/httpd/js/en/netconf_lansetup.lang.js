<script>
var NETCONF_INTERNAL_INVALID_LEASETIME="Please select lease time"

var NETCONF_LANSETUP_APPLYSTR = 'Applying...';
var NETCONF_LANSETUP_PARTAPPLY = 'Retrieving internal network info..';
var NETCONF_LANSETUP_REBOOTMSG1 = '<p>Rebooting..</p><p>';
var NETCONF_LANSETUP_REBOOTMSG2 = ' sec remain</p>';
var NETCONF_LANSETUP_CURPC_ALERT = 'Internet connection for currently connected device will be disconnected.\ndo you want continue?';

var NETCONF_LANSETUP_HUBAP_ALERT = 'If you on and apply this function,DHCP server will be OFF.\ndo you want continue?';
var NETCONF_LANSETUP_INVALID_GATEWAY="Invalid gateway."
var NETCONF_LANSETUP_PLZ_CHANGE="Please change the gateway or internal IP.\nThey must be same subnet."

var LANSETUP_SEARCH_SUCCESS="Search success"
var LANSETUP_SEARCH_FAILED="Search failed"
var LANSETUP_SEARCH_FAILED2="Please set up manually."

var MSG_ERROR_NETWORK_LANIP="LAN IP address can't be the same as Network Address"
var MSG_ERROR_BROAD_LANIP="LAN IP address can't be the same as Local Broadcast Address"
var MSG_DESC_TOO_LONG = 'You can enter desc 20 bytes\nif non-ascii character is 3 bytes each\ncurrent byte : ';
var LANSETUP_RESTART_CONFIRM_CHANGE_LANIP='System will restart to change LAN IP address.\nAre you sure to continue ?';
var LANSETUP_RESTART_CONFIRM_CHANGE_LANIP_FAKE_TWINIP='System will restart to change LAN IP address.\nAre you sure to continue ?';
var LANSETUP_REBOOT_CHANGEIP_RETRY_LOGIN="Because of LAN setting change, Reconnect."
</script>
