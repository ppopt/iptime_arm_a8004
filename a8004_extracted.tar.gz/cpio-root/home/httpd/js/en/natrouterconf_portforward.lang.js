<script>

var PORTFORWARD_APPLY_STRING = "Apply";
var PORTFORWARD_MODIFY_STRING = "Modify";

var PORTFORWARD_IPADDR_INVALID = "IP Address is invalid";
var PORTFORWARD_RULE_NAME_BLANKED = "Rule name has not been entered";
var PORTFORWARD_PORT_INVALID = "Port is invalid.";

var PORTFORWARD_RULE_DELETE = "Are you sure to delete rule?";
var PORTFORWARD_NOT_SELECTED_STRING = "No rules selected.";
var PORTFORWARD_RULE_NAME_INVALID = "There are special characters that are not permitted in the rule name."
var PORTFORWARD_INT_IP_ALERT = "Router internal address can not port forward.";
var PORTFORWARD_BROD_IP_ALERT = "Broadcast address can not port forward.";
var PORTFORWARD_MAX_RULE_ALERT = "You can not add more rules.";
var PORTFORWARD_FILE_NOT_EXIST = "The file is not selected.";
var PORTFORWARD_RULE_NAME_EXIST = "There is a duplicate name for the rule.\nPlease enter a different name for the rule.";

</script>
