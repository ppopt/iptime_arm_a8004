<script>
var TRAFFICCONF_SWITCH_WARNING_TURNOFF_TRUNK		= "LAN port is already used. Turn off the port mirroring function."
var TRAFFICCONF_SWITCH_WARNING_TURNOFF_PORTMIRROR	= "LAN port is already used. Turn off the port trunking function."

</script>



