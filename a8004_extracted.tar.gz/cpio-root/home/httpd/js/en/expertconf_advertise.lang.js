<script>
var EXPERTCONF_ADVERTISE_ADDSTR = "Adding..";
var EXPERTCONF_ADVERTISE_DELSTR = "Deleting..";
var EXPERTCONF_ADVERTISE_APPLYSTR = "Applying..";

var EXPERTCONF_ADVERTISE_URLREDIR_INVALID = "Please check a notice URL";
var EXPERTCONF_ADVERTISE_CYCLE_INVALID = "Please check a cycle.";
var EXPERTCONF_ADVERTISE_BTNMSG_INVALID = "Please check a user phrase button";
var EXPERTCONF_ADVERTISE_USERMSG_INVALID = "Please check a user phrase when confirm";
var EXPERTCONF_ADVERTISE_USERMSG2_INVALID = "Please check a user phrase after confirm";
var EXPERTCONF_ADVERTISE_WHITELIST_INVALID = "Please check a white list.";

var EXPERTCONF_ADVERTISE_NOCHECK_DEL = "Please check a checkbox";
var EXPERTCONF_ADVERTISE_IPRANGE_INVALID = "IP range is invalid";
var MSG_DESC_TOO_LONG = 'You can enter 255 bytes\nif non-ascii character is 3 bytes each\ncurrent byte : ';
var MSG_DESC_TOO_LONG2 = 'You can enter 128 bytes\nif non-ascii character is 3 bytes each\ncurrent byte : ';
var ACCESSLIST_WRITE_EXPLAIN="Description is blank."
</script>
