<script>
var EXPERTCONF_DDNS_DELCONFIRM = "Do you want delete a DDNS?";
var EXPERTCONF_DDNS_ADDSTR = "DDNS adding..";
var EXPERTCONF_DDNS_DELSTR = "DDNS deleting..";
var EXPERTCONF_DDNS_REFRESHSTR = "DDNS refreshing..";
var EXPERTCONF_DDNS_HOSTNAMECHECK = "Please enter a hostname";
var EXPERTCONF_DDNS_USERIDCHECK = "Please enter a user id";
var EXPERTCONF_DDNS_CAPTCHACHECK = "Please enter a security code";
var DDNS_HOSTNAME_RULE_TXT="Invalid DDNS HostName"
var SYSCONF_LOGIN_NEED_CAPTCHA_CODE="Fill security code"
var EXPERTCONF_DDNS_HOSTNAME_IS_BLANK = "Host name is blank."
var EXPERTCONF_IPTIMEDNS_NOMORE_WANRING1 ="No more ipTIME DDNS Host."
var EXPERTCONF_DDNS_HOSTNAME_NOT_IPTIMEORG = "Host name must be end whid iptime.org."
var EXPERTCONF_IPTIMEDDNS_INVALID_USERID= "Only E-mail Address available."
var EXPERTCONF_DYNDNS_NOMORE_WANRING1="No more Dyndns Host."
var MSG_BLANK_ACCOUNT="Put the User ID."
var MSG_BLANK_PASSWORD="Put the Password."
</script>
