<script>
var NETCONF_INTERNAL_INVALID_LEASETIME="Please select lease time"

var NETCONF_DHCP_APPLYSTR = 'Applying...';
var NETCONF_DHCP_REBOOTMSG1 = '<p>Rebooting..</p><p>';
var NETCONF_DHCP_REBOOTMSG2 = ' sec remain</p>';
var NETCONF_DHCP_INVALID_ADDR="Invalid DHCP pool range"
var NETCONF_DHCP_SIP_CALC_FAIL = 'DHCP start ip is wrong';
var NETCONF_DHCP_EIP_CALC_FAIL = 'DHCP end ip is wrong';
var NETCONF_DHCP_CURPC_ALERT = 'Internet connection for currently connected device will be disconnected.\ndo you want continue?';
var NETCONF_DHCP_UNPERMITTED_ALERT = 'Can not enter special characters in the description.';

var MSG_INVALID_DHCP_NETMASK="Invalid subnet mask."
var MSG_INVALID_DHCP_GATEWAY="Invalid gateway."

var MSG_ERROR_NETWORK_DHCP="can't be the same as Network Address"
var MSG_ERROR_BROAD_DHCP="can't be the same as Broadcast Address"
var MSG_DESC_TOO_LONG = 'You can enter desc 20 bytes\nif non-ascii character is 3 bytes each\ncurrent byte : ';
</script>
