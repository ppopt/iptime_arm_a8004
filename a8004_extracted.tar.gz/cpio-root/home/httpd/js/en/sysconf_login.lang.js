<script>
var SYSCONF_LOGIN_CANT_REMOVE_ID  = "ID & Password can't be removed when Session method is used."
var SYSCONF_LOGIN_CANT_REMOVE_WARNING="Fill the admin account & password"
var CANT_SET_DEFAULT_ID_PASS="This is factory default account & password.\nChange the account & password."
var SYSCONF_LOGIN_INVALID_NEW_PASS=     "Your New password entries did not match."
var SYSCONF_LOGIN_INVALID_NEW_ID  =     "Invalid new account string: only allowed for alphabet and numeric character."
var SYSCONF_LOGIN_RELOGIN         =     "You would re-login the system,if you altered a password."
var SYSCONF_LOGIN_RELOGIN_SESSION  = "Move to Login page after configuring. Continue?"
var SYSCONF_LOGIN_SHOULD_HAVE_IDPASS  = "To enable Session, ID & Password MUST be set."
var SYSCONF_LOGIN_INVALID_SESSION_TIMEOUT  = "Session Timeout should be 1 ~ 60 minutes."
var SYSCONF_CAPTCHA_ATTEMPT_RANGE_WARNING = "The allowance of login failure can be set from 0 to 99.";

var SYSCONF_LOGIN_APPLYSTR  = "Applying.."
var SYSCONF_LOGIN_DELETESTR  = "Deleting.."
var SYSCONF_EMAIL_INVALID  = "Invalid E-mail"
var SYSCONF_EMAIL_SMTP_INVALID  = "Invalid SMTP server"
var SYSCONF_EMAIL_ACCOUNT_INVALID  = "Invalid account"
var SYSCONF_EMAIL_DEL_CONFIRM  = "E-mail setup will be deleted.\ncontinue?"
</script>
