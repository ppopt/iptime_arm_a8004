<script>
var MSG_INVALID_FOLDER_STR="Invalid Folder String.";
var MSG_INVALID_FOLDER_NON_ASCII_STR="Only Ascii folder name is allowed.";
var MSG_INVALID_FOLDER_2DOTS_STR=".. can't be used."
var MSG_INVALID_FOLDER_DOT_STR=". can't be used at the start of folder name."
var MSG_CANT_BE_USED="can't be used."
var MSG_INVALID_PASSWORD_STR="Invalid password."
var NASCONF_SAMBANAME_BLANK= "Server name is blank."
var NASCONF_SAMBAGROUP_BLANK= "Workgroup is blank."

var EXPERTCONF_IPTIMEDDNS_INVALID_USERID= "Only E-mail Address available."
var EXPERTCONF_IPTIMEDDNS_INVALID_HOSTNAME = "'_' or '.' charater not allowed in a host name"

var MSG_REMOVE_IPDISK_DDNS="This action will cancel the ipDISK DDNS registration.\nSo, other use can use this hostname.\nContinue?"
var MSG_APACHE_INVALID_FS="The filesystem of DocumentRoot is FAT32 or ExFAT\nIn this case, [Plug-in App] can't be used.\nRecommend to use NTFS or Ext2/3/4(Linux).\nContinue?"

var MSG_SELECT_MYSQL_FOLDER_ERR="Select DB folder."
var MSG_SELECT_APACHE_DOC_FOLDER_ERR="Select DocumentRoot."
var MSG_SELECT_APACHE_SERVER_FOLDER_ERR="Select ServerRoot."
var MSG_NEW_FOLDER_ERR="Fill the Folder Name."
var MSG_MEDIA_NAME_ERR="Fill the Name field"
var MSG_SELECT_MEDIA_FOLDER_ERR="Select Media Folder"
var MSG_SELECT_TORRENT_FOLDER_ERR="Select Download Folder"
var MSG_SELECT_FOLDER_ERR="Choose Backup Folder"
var MSG_DUPLICATE_SERVICE_ID="Some ID is duplicated. Change the User ID."
var MSG_ENABLE_ONE_SERVICE_ID="At least one user is needed to run."
var UNALLOWED_ID_MSG  = "Unallowed Used ID"

var MSG_APACHE_DOCROOT_SERVERROOT_WARNING = "DocumentRoot and ServerRoot should be different.";

var NASCONF_ENTWARE_ACCESS_DENY = "Please retry after admin setup.";
var MSG_SELECT_ENTWARE_FOLDER_ERR="Select Entware Folder"
var NASCONF_ENTWARE_INSTALL_CONDITION_CHECK = "Folder not found. Please check a folder, and retry action.";
var NASCONF_ENTWARE_STATUS_INSTALLING = 'Installing..';
var NASCONF_ENTWARE_STATUS_READY = 'Installed';
var NASCONF_ENTWARE_STATUS_ERROR = 'Install fail';
</script>
