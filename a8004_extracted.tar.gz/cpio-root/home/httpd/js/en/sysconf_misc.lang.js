<script>
var MSG_RESTART_CONFIRM_DEFAULT='System will restart for factory default.\nAre you sure to continue ?';
var MSG_RESTOREFILE_BLANK="Select a configuration backup file."
var MSG_RESTART_CONFIRM_RESTORE= 'System will restart after recovering the configuration\n Are you sure to continue ?';
var SYSCONF_RESTORE_RETRY_CONNET="Reconnect to the restore configuration page."

var SYSCONF_HOSTNAME_WARNING="The router name must be at least one letter."
var SYSCONF_HOSTNAME_SPECIAL_WARNING="The router name can't be entered special characters and spaces."
var SYSCONF_LED_START_TIME_ALERT="The start time can't be later than the end time."
var SYSCONF_APPLY_BUTTON_NAME="Reboot"
var SYSCONF_APPLY_ORIGINAL_VALUE="Apply"
var SYSCONF_FAN_ALERT="Temperature range setting is incorrect."

var SYSCONF_INVALID_HOSTNAME="Invalid HostName"
var UNPERMITTED_STR_PREFIX="Unpermitted characters:"
var SYSCONF_INVALID_TEMPERATURE="Invalid Temperature.(Temperature <= 100)"

var SYSCONF_SET_URL_TAG="Set URL TAG first."
var SYSCONF_MISC_MULTILANG_WARNING	= "Move to Status Summary page after configuring. Continue?"

var MSG_RESTART_PORT_ROLE	= "Accessing setup page may fail after restarting system\nContinue?"

</script>
