
<script>
/*
var QOS_BASIC_WARNING="All QoS configurations would be reset. Carry on this process?"
var QOS_COMMON_EXCCED_MAX_CLASS="Excced max number of class."
var QOS_COMMON_NO_CHANGE_DIRECTION="Can't change a direction of class."
var QOS_COMMON_ONLY_DIGIT="Only digit available."
var QOS_COMMON_BASIC_SETUP_FIRST="QoS Basic setup first."
var QOS_RATE_RANGE="Rate range : 32 Kbps ~ 50 Mbps"
*/

var QOS_SMARTQOS_WARNING_USERRULE_DELETE	= "All QoS configurations would be reset. Carry on this process?"
var QOS_USERRULE_WARNING_NEED_BANDWIDTH		= "You should set bandwidth of internet.";
var QOS_USERRULE_WARNING_PRIORITY_ORDER		= "Priority order is wrong\nWould you correct it automatically?";
var QOS_USERRULE_WARNING_BANDWIDTH_SPEED	= "Internet bandwidth value is fault.";

var QOS_COMMON_EXCCED_MAX_SPEED			= "Excced max internet speed range."
var QOS_COMMON_ISOLATED_EXCEED			= "Total bandwidth sum of classes which has 'isolated' proerty cat NOT exceed max internet speed rang"
var QOS_PROTOCOL_SELECT				= "Select a Protocol type."
var QOS_PORT_PORTRANGE				= "Port range should be from 1 to 65,535"
var QOS_PORT_INVALID_EXT_PORT_RANGE		= "Invalid External Port Range."
var QOS_BADNWIDTH_EMPTY				= "Bandwidth Field Empty."
var QOS_BPI_RANGE				= "Invaild IP address range for BPI. (Available: 2 ~ 31)"
var MSG_QOS_REBOOT				= "QOS 설정을 변경하기위해서는 시스템을 재시작해야합니다. 계속하시겠습니까?"
</script>
